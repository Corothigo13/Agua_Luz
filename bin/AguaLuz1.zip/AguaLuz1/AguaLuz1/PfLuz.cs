﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AguaLuz1
{
    class PfLuz : PessoaFisica, Luz1
    {
        public PfLuz()
        { }
        public double CalcularConsumo(double leituraant, double leituraatu)
        {
            double consumo = 0;
            consumo = leituraatu - leituraant;
            return consumo;
        }
        public double CalcularConta(double consumo)
        {
            double conta = 0;
            conta = 0.46 * consumo;
            conta = conta + 13.25;
            if (consumo > 90)
            {
                conta = conta * 1.4285;
            }
            return conta;
        }
}
}
