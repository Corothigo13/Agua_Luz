﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AguaLuz1
{
    class SalvarCadastroPJAgua:Cadastro
    {
        string nomeCP,cnpj,endereco,estado,cep;
        public SalvarCadastroPJAgua(string nomeCP,string cnpj,string endereco,string estado,string cep)
        {
            this.nomeCP = nomeCP;
            this.cnpj = cnpj;
            this.endereco = endereco;
            this.estado = estado;
            this.cep = cep;
        }
        public override void Salvando()
        {
            FileStream arq = new FileStream("CadastroPjAgua.txt", FileMode.Append);
            StreamWriter escreve = new StreamWriter(arq);
            escreve.WriteLine(nomeCP.ToUpper() + "," + cnpj.ToUpper()+","+endereco.ToUpper() + "," + estado.ToUpper() + "," + cep.ToUpper());
            escreve.Close();
        }
    }
}
