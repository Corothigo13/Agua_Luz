﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AguaLuz1
{
    class Cliente
    {
        private string nome, senha;
        public void setNome(string nome)
        {
            this.nome = nome;
        }
        public string getNome()
        {
            return nome;
        }
        public void setSenha(string senha)
        {
            this.senha = senha;
        }
        public string getSenha()
        {
            return senha;
        }

        public Cliente()
        { }
        public bool VerificarUsuario(string usuario,string arquivo)
        {
            bool verificar = false;
            string usuarioArq;
            string[] linhas = File.ReadAllLines(arquivo);
            for(int i=0;i<linhas.Length;i++)
            {
                string[] auxiliar;
                auxiliar = linhas[i].Split('|');
                usuarioArq = auxiliar[0];
                if(usuarioArq==usuario)
                {
                    verificar = true;
                }                
            }
            return verificar;
        }
        public bool VerificarSenha(string senha, string arquivo)
        {
            bool verificar = false;
            string senhaArq;
            string[] linhas = File.ReadAllLines(arquivo);
            for (int i = 0; i < linhas.Length; i++)
            {
                string[] auxiliar;
                auxiliar = linhas[i].Split('|');
                senhaArq = auxiliar[1];
                if (senhaArq == senha)
                {
                    verificar = true;
                }
            }
            return verificar;
        }
    }
}
