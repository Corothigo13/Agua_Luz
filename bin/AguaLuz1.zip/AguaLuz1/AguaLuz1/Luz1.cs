﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AguaLuz1
{
    interface Luz1
    {
        double CalcularConsumo(double leituraant, double leituraatu);
        double CalcularConta(double consumo);
    }
}
