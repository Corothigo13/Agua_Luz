﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AguaLuz1
{
    class SalvarCadastroPfAgua:Cadastro
    {
        string nome,cnpj,estado,cep,endereco;
        public SalvarCadastroPfAgua(string nome,string cnpj,string endereco)
        {
            this.nome = nome;
            this.cnpj = cnpj;
            this.endereco = endereco;

        }
        public override void Salvando()
        {
            FileStream arq = new FileStream("CadastroPFAgua.txt", FileMode.Append);
            StreamWriter escreve = new StreamWriter(arq);
            escreve.WriteLine(nome.ToUpper() + "|" + cnpj.ToUpper()+","+endereco.ToUpper() + "," + estado.ToUpper() + "," + cep.ToUpper());
            escreve.Close();
        }
        
    }
}
