﻿namespace AguaLuz1
{
    partial class Luz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Luz));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.CONSULTA1 = new System.Windows.Forms.Button();
            this.CADAST_CON1 = new System.Windows.Forms.Button();
            this.CADAST_USU1 = new System.Windows.Forms.Button();
            this.CONSULTA = new System.Windows.Forms.Button();
            this.CADAST_CON = new System.Windows.Forms.Button();
            this.CADAST_USU = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(259, 281);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(167, 74);
            this.button1.TabIndex = 24;
            this.button1.Text = "CADASTRAR CLIENTE (PESSOA  JURIDICA)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(259, 119);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(167, 162);
            this.button2.TabIndex = 23;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // CONSULTA1
            // 
            this.CONSULTA1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CONSULTA1.Location = new System.Drawing.Point(711, 281);
            this.CONSULTA1.Name = "CONSULTA1";
            this.CONSULTA1.Size = new System.Drawing.Size(158, 74);
            this.CONSULTA1.TabIndex = 22;
            this.CONSULTA1.Text = "CONSULTAS ";
            this.CONSULTA1.UseVisualStyleBackColor = true;
            this.CONSULTA1.Click += new System.EventHandler(this.CONSULTA1_Click);
            // 
            // CADAST_CON1
            // 
            this.CADAST_CON1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CADAST_CON1.Location = new System.Drawing.Point(487, 281);
            this.CADAST_CON1.Name = "CADAST_CON1";
            this.CADAST_CON1.Size = new System.Drawing.Size(158, 74);
            this.CADAST_CON1.TabIndex = 21;
            this.CADAST_CON1.Text = "CADASTRAR CONSUMO";
            this.CADAST_CON1.UseVisualStyleBackColor = true;
            this.CADAST_CON1.Click += new System.EventHandler(this.CADAST_CON1_Click);
            // 
            // CADAST_USU1
            // 
            this.CADAST_USU1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CADAST_USU1.Location = new System.Drawing.Point(62, 281);
            this.CADAST_USU1.Name = "CADAST_USU1";
            this.CADAST_USU1.Size = new System.Drawing.Size(158, 74);
            this.CADAST_USU1.TabIndex = 20;
            this.CADAST_USU1.Text = "CADASTRAR CLIENTE (PESSOA FÍSICA)";
            this.CADAST_USU1.UseVisualStyleBackColor = true;
            this.CADAST_USU1.Click += new System.EventHandler(this.CADAST_USU1_Click);
            // 
            // CONSULTA
            // 
            this.CONSULTA.Image = ((System.Drawing.Image)(resources.GetObject("CONSULTA.Image")));
            this.CONSULTA.Location = new System.Drawing.Point(711, 119);
            this.CONSULTA.Name = "CONSULTA";
            this.CONSULTA.Size = new System.Drawing.Size(157, 162);
            this.CONSULTA.TabIndex = 19;
            this.CONSULTA.UseVisualStyleBackColor = true;
            this.CONSULTA.Click += new System.EventHandler(this.CONSULTA_Click);
            // 
            // CADAST_CON
            // 
            this.CADAST_CON.Image = ((System.Drawing.Image)(resources.GetObject("CADAST_CON.Image")));
            this.CADAST_CON.Location = new System.Drawing.Point(488, 119);
            this.CADAST_CON.Name = "CADAST_CON";
            this.CADAST_CON.Size = new System.Drawing.Size(157, 162);
            this.CADAST_CON.TabIndex = 18;
            this.CADAST_CON.UseVisualStyleBackColor = true;
            this.CADAST_CON.Click += new System.EventHandler(this.CADAST_CON_Click);
            // 
            // CADAST_USU
            // 
            this.CADAST_USU.Image = ((System.Drawing.Image)(resources.GetObject("CADAST_USU.Image")));
            this.CADAST_USU.Location = new System.Drawing.Point(62, 119);
            this.CADAST_USU.Name = "CADAST_USU";
            this.CADAST_USU.Size = new System.Drawing.Size(158, 162);
            this.CADAST_USU.TabIndex = 17;
            this.CADAST_USU.UseVisualStyleBackColor = true;
            this.CADAST_USU.Click += new System.EventHandler(this.CADAST_USU_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(945, 485);
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Luz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 485);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.CONSULTA1);
            this.Controls.Add(this.CADAST_CON1);
            this.Controls.Add(this.CADAST_USU1);
            this.Controls.Add(this.CONSULTA);
            this.Controls.Add(this.CADAST_CON);
            this.Controls.Add(this.CADAST_USU);
            this.Controls.Add(this.pictureBox2);
            this.Name = "Luz";
            this.Text = "Luz";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button CONSULTA1;
        private System.Windows.Forms.Button CADAST_CON1;
        private System.Windows.Forms.Button CADAST_USU1;
        private System.Windows.Forms.Button CONSULTA;
        private System.Windows.Forms.Button CADAST_CON;
        private System.Windows.Forms.Button CADAST_USU;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}