﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AguaLuz1
{
    class Cadastro
    {
        string nome, cnpj, estado, cep, endereco;
        public virtual void Salvando()
        {
        }
        public string getNome()
        {
            return nome;
        }
        public string getCnpf()
        {
            return cnpj;
        }
        public string getEstado()
        {
            return estado;
        }
        public string getCep()
        {
            return cep;
        }
        public string getEndereco()
        {
            return endereco;
        }
    }
}
