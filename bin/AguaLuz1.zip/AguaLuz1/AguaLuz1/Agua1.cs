﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AguaLuz1
{
    interface Agua1
    {
        double CalcularConsumo();
        void CalcularConta();
    }
}
