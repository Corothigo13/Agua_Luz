﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AguaLuz1
{
    public partial class CadastroPJ_Agua : Form
    {
        public CadastroPJ_Agua()
        {
            InitializeComponent();
        }

        private void CONSULTA1_Click(object sender, EventArgs e)
        {
            SalvarCadastroPJAgua SalvarPj = new SalvarCadastroPJAgua(textBox1.Text, textBox3.Text,textBox4.Text, comboBox1.Text, textBox2.Text);
            SalvarPj.Salvando();
            FazerOutraOperacao FO = new FazerOutraOperacao();
            FO.Show();
        }
    }
}
