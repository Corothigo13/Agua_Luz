﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AguaLuz1
{
    class CadastroConsumo
    {
        string CnpjCpf,cep,mes;
        double consumoL, ano;
        public CadastroConsumo(string CnpjCpf,string cep,double consumoL,string mes,double ano)
        {
            this.CnpjCpf = CnpjCpf;
            this.cep = cep;
            this.consumoL = consumoL;
            this.mes = mes;
            this.ano = ano;
        }
        public void SalvaConsumoAgua()
        {
            FileStream arq = new FileStream("CadastroConsumoAgua.txt",FileMode.Create);
            StreamWriter escreve = new StreamWriter(arq);
            escreve.WriteLine(CnpjCpf + "," + cep + "," + consumoL + "," + mes + "," + ano);
            escreve.Close();
        }
    }
}
